import React from 'react';
import './NewsAndUpdates.css';

const NewsAndUpdates = () => {
  return (
    <div>NewsAndUpdates</div>
  )
}

export default NewsAndUpdates